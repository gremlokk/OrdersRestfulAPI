const express = require('express');
const router = express.Router();//creates post/get and other HTTP requests
const mongoose = require('mongoose');

const Order = require('../models/order');

router.get('/', (req,res,next) => {//handles get requests
    Order.find()
        .exec()
        .then(docs => {
            if (docs.length >=0){
                res.status(200).json(docs);
            }
            else{
                res.status(404).json({message: 'No entries found'})
            }
        });
});

router.get('/:orderId', (req,res,next) => {//handles get requests
    const id = req.params.orderId;
    Order.findById(id)
        .exec()
        .then(doc => {
            console.log("From database", doc);
            res.status(200).json(doc);
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({error: err});
        });
});

router.post('/', (req,res,next) => {//handles post requests
    const order = new Order({
        _id: new mongoose.Types.ObjectId(),
        itemName: req.body.itemName,
        quantity: req.body.quantity
     });//creates mongo obj to save to db
 
     order
         .save()
         .then(result =>{//stores obj in db
            res.status(200).json(docs);
            console.log(result);
         })
         .catch(err => console.log(err));
 
     res.status(201).json({
         message: 'Handling POST requests to /products',
         createdOrder: order
     });
});

router.delete('/', (req,res,next) => {
    Order.remove()
    .exec()
        .then(docs => {
            if(!docs) {
                res.status(404).send({message: "Docs not found"});
            }
            res.send({message: "Documents deleted successfully!"});
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({error: err});
        });
});

router.delete('/:orderId', (req,res,next) => {
    const id = req.params.orderId;
    Order.remove({_id:id})
    .exec()
        .then(docs => {
            if(!docs) {
                res.status(404).send({message: "Docs not found"});
            }
            res.send({
                message: 'Document with id' + id + ' deleted successfully!',
                orderId: id
            });
        })
        .catch(err => {
            console.log(err);
            res.status(500).json({error: err});
        });
});

module.exports = router;//used for importing routes to app.js file
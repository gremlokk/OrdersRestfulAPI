const http = require('http');
const app = require('./app');//import main module for route handling

const port = process.env.port || 3001;//port for server to be on

const server = http.createServer(app);//create server for app

server.listen(port);